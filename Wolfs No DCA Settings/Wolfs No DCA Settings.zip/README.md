The creators of this Wiki and the related script are not financial advisors, and as such, this Wiki or script is not financial advice. Anything seen or used within this Wiki or script is here simply for educational purposes and it is up to you to decide what to do with this information and results. Please do your own research and verify any statements made before deciding to act upon them. Do not commit any of your own resources to any trading or cryptocurrency activities without first verifying the accuracy of the information and know that your decisions are your own.

Note: You HAVE TO make changes to various settings. For instance market, start_balance, DEFAULT_initial_cost etc. according to your own situation and the market you are trading!

Check the Wiki for further documentation: https://github.com/smoochy/WolfsOfCrypto/wiki
